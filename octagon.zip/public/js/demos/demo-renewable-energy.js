/*
Name:           Demo Renewable Energy
Written by:     Okler Themes - (http://www.okler.net)
Theme Version:  9.9.1
*/

(function( $ ) {
	
	'use strict';

	

}).apply( this, [ jQuery ]);
